import React from 'react'
import Navbar from '../components/navbar'

const Home = () => {
  return (
    <div>
      <Navbar></Navbar>
    </div>
  )
}

export default Home
