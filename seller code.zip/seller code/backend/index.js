const express=require('express');
const app=express();
require('./db');
const multer  = require('multer')
var cors = require('cors')
const usersRegistration=require("./controllers/userscontroller");
const sellingproducts=require('./controllers/productscontroller');
app.use(express.json());
app.use(cors());
app.use(express.urlencoded({ extended: false }))
app.use(express.static('uploads'))


const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, 'uploads')
    },
    filename: function (req, file, cb) {
      const uniqueSuffix = Date.now() ;
      cb(null, uniqueSuffix + '-' + file.originalname )
    }
  })
  
  const upload = multer({ storage: storage })


app.post('/signup', usersRegistration.signup);
app.post('/signin', usersRegistration.signin);
app.patch('/user/:userid',usersRegistration.updateuser)
app.post('/products', upload.single('image'), sellingproducts.products);
app.get('/getproducts', sellingproducts.getproducts);
app.get('/productdetail/:productId', sellingproducts.detailproduct)
app.get('/products/:userid', sellingproducts.userproducts)
app.patch('/updateproduct/:userid',upload.single('image'), sellingproducts.updateproduct);
app.delete('/deleteproduct/:userid', sellingproducts.deleteproduct);





app.listen(6500,()=>{
    console.log("connected successfull ");
})