import React from 'react'
import sellingform from '../components/sellingform';
const Seller = () => {
  return (
    <>
    <sellingform/>
    </>
  )
}

export default Seller
