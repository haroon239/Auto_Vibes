import React from 'react'
import Navbar from '../components/navbar'
import Herosection from '../components/herosection'
import Product from '../components/product'
import SearchFilter from '../components/searchFilter'
const Home = () => {
  return (
    <div>
      <Navbar></Navbar>
<Herosection></Herosection>
<SearchFilter/>
<Product/>
    </div>
  )
}

export default Home
