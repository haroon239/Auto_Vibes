import {BrowserRouter, Routes, Route} from "react-router-dom";
import Signin from "./pages/signin";
import Signup from "./pages/signup";
import Home from "./pages/home";
import Seller from './components/sellingform'
import Productdetail from "./pages/productdetail";
import Profile from "./pages/profile";

function App() {
  return (
 <BrowserRouter>
 <Routes>
  <Route path="/" element={<Home/>}></Route>
  <Route path="/signin" element={<Signin/>}></Route>
  <Route path="/signup" element={<Signup/>}></Route>
  <Route path="/seller" element={<Seller/>}></Route>
  <Route path="/product/detail/:_id" element={<Productdetail/>}></Route>
  <Route path="/profile" element={<Profile/>}></Route>


  

 </Routes>
 </BrowserRouter>
  )
}

export default App
